#!/bin/bash

RDO_RELEASE=https://repos.fedorapeople.org/repos/openstack/openstack-kilo/rdo-release-kilo-1.noarch.rpm

. sf_rdo_slave_setup.sh
