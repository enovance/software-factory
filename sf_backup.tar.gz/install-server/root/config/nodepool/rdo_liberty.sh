#!/bin/bash

RDO_RELEASE=https://repos.fedorapeople.org/repos/openstack/openstack-liberty/rdo-release-liberty-2.noarch.rpm

. sf_rdo_slave_setup.sh
