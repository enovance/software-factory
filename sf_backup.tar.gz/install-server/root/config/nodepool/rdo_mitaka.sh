#!/bin/bash

RDO_RELEASE=https://repos.fedorapeople.org/repos/openstack/openstack-mitaka/rdo-release-mitaka-5.noarch.rpm

. sf_rdo_slave_setup.sh
